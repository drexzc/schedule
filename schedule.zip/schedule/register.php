<?php
// Include the database connection file
include 'db-connect.php';

// Define error variable
$error_message = "";

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get and sanitize user input
    $email = $conn->real_escape_string(trim($_POST['email']));
    $password = $_POST['password'];

    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_message = "Invalid email format.";
    }

    // Hash the password
    $hashed_password = password_hash($password, PASSWORD_BCRYPT);

    // If email is valid, proceed with registration
    if (empty($error_message)) {
        // Prepare the SQL statement
        $sql = "INSERT INTO users (email, password) VALUES (?, ?)";
        $stmt = $conn->prepare($sql);

        if ($stmt) {
            // Bind parameters (s for string type)
            $stmt->bind_param("ss", $email, $hashed_password);

            // Try to execute the statement
            if ($stmt->execute()) {
                // Registration successful; redirect to login page
                header("Location: login.html");
                exit; // Ensure the script stops after the redirect
            } else {
                // Handle errors that occur during execution
                if ($stmt->errno === 1062) { // Error code for duplicate entry (email)
                    $error_message = "Error: Email already exists. Please try a different email.";
                } else {
                    $error_message = "Error: " . $stmt->error; // General error message
                }
            }

            // Close the statement
            $stmt->close();
        } else {
            // Handle prepare statement errors
            $error_message = "Prepare failed: " . $conn->error;
        }
    }
}

// Close the connection
$conn->close();

// If there are any errors, display them
if (!empty($error_message)) {
    echo "<p style='color: red;'>$error_message</p>";
}
?>
