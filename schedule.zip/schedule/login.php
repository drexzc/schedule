<?php
// Start the session at the top
session_start();

// Include the database connection file
include 'db-connect.php';

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Prepare a query to fetch the user with the given email
    $sql = "SELECT * FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);

    if ($stmt) {
        // Bind the parameter (s for string type)
        $stmt->bind_param("s", $email);

        // Execute the statement
        $stmt->execute();

        // Fetch the user record
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        if ($user && password_verify($password, $user['password'])) {
            // Password is correct
            // Set session variables to identify the user
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['email'] = $user['email'];

            // Redirect to the index.php page
            header("Location: index.php");
            exit; // Ensure the script stops after the redirect
        } else {
            // Incorrect email or password
            echo "<p>Invalid email or password. Please try again.</p>";
            echo '<a href="login.html">Go back to login page</a>';
        }
    } else {
        echo "Error: Could not prepare the SQL query.";
    }

    // Close the statement
    $stmt->close();
}

// Close the connection
$conn->close();
?>
