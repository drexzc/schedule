<?php
session_start();

require_once('db-connect.php');

// Get the schedule ID from the URL or POST data
$schedule_id = $_GET['id'] ?? null;

// Check if user is logged in
$user_email = $_SESSION['user_email'] ?? null;

if (!$user_email || !$schedule_id) {
    echo "<script> alert('Error: Unauthorized access.'); location.replace('./') </script>";
    exit;
}

// Check if the schedule belongs to the logged-in user
$result = $conn->query("SELECT * FROM `schedule_list` WHERE `id` = '$schedule_id' AND `user_email` = '$user_email'");

if ($result->num_rows > 0) {
    // Proceed to delete
    $conn->query("DELETE FROM `schedule_list` WHERE `id` = '$schedule_id' AND `user_email` = '$user_email'");
    echo "<script> alert('Schedule deleted successfully.'); location.replace('./') </script>";
} else {
    echo "<script> alert('Error: Unauthorized action.'); location.replace('./') </script>";
}

$conn->close();
?>
