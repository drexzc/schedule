<?php
$host = 'localhost';
$username = 'root';
$password = '';
$dbname = 'dummy_db';

// Create a new mysqli instance
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
